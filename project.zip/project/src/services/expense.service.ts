import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ExpenseService {

  constructor(private http:HttpClient) { }

  postExpense(data:any){
    return this.http.post<any>("https://localhost:5001/api/v1/expence",data);
  }

  getExpenses(id:any){
    return this.http.get<any>(`https://localhost:5001/api/v1/expence?id=${id}`)
  }

  editExpense(id:any,expenseId:any,data:any){
    return this.http.patch<any>(`https://localhost:5001/api/v1/expence?id=${id}&expenceId=${expenseId}`,data)
  }

  deleteExpense(id:any){
    return this.http.delete<any>(`https://localhost:5001/api/v1/expence?expenceId=${id}`)
  }

}
