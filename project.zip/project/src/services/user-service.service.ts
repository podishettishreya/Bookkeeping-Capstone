import { CookieService } from 'ngx-cookie-service';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private http:HttpClient) { }
  postDetails(data: any){ //for signin

    return this.http.post<any>("https://localhost:5001/api/v1/student",data)

  }
  Login(data: any){     //for login
    
    return this.http.get<any>(`https://localhost:5001/api/v1/student?name=${data.name}&password=${data.password}`)

    // return this.http.post<any>("https://localhost:5001/api/v1/login",data)
  }
}
