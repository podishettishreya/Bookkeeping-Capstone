import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ExpenseService } from 'src/services/expense.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-expense-edit',
  templateUrl: './expense-edit.component.html',
  styleUrls: ['./expense-edit.component.css']
})
export class ExpenseEditComponent implements OnInit {

  

  expence!:FormGroup;
  toppings = new FormControl('');
  toppingList: string[] = ['Paid', 'Unpaid'];
  pay = new FormControl('');
  payList: string[] = ['Credit', 'Debit'];
  id = this.activatedRoute.snapshot.paramMap.get("id");
  expenceId = this.activatedRoute.snapshot.paramMap.get("expenceId");
  constructor(private activatedRoute:ActivatedRoute,private fb:FormBuilder,private api:ExpenseService,private router:Router) { }
  _expense:any = {}

  ngOnInit(): void {
    
    this.api.getExpenses(this.id).subscribe((response)=>{
      for(let i = 0;i<response.length;i++){
        if( response[i].id == this.expenceId){
          response[i].expenseDate = response[i].expenseDate.split("T")[0]
          response[i].expenseDueDate = response[i].expenseDueDate.split("T")[0]
          this._expense={...response[i]}
        }
        
      } 
      console.log(this._expense)
      this.expence = this.fb.group({
        name: [this._expense.expenseName, Validators.required],
        amount: [this._expense.expenseAmount,Validators.required],
        date:[this._expense.expenseDate,Validators.required],
        status:[this._expense.expenseStatus,Validators.required],
        type:[this._expense.expenseType,Validators.required],
        duedate:[this._expense.expenseDueDate,Validators.required],
        accounttype:[this._expense.expenseAccountType,Validators.required]
      })

    })
    
  }

  submit(){
    if(this.expence.valid){
      console.log(this.expence.value)
      let data:any={}
      data['ExpenseName']= this.expence.value.name
      data['ExpenseAmount']= this.expence.value.amount
      data['ExpenseDate']= this.expence.value.date
      data['ExpenseStatus']= this.expence.value.status
      data['ExpenseType']= this.expence.value.type
      data['ExpenseDueDate']= this.expence.value.duedate
      data['ExpenseAccountType']= this.expence.value.accounttype
      data['UserId'] = this.id
      this.api.editExpense(this.id,this.expenceId,data).subscribe((response)=>{
        console.log(response)
        this.router.navigate([`/homepage/${this.id}`])
      })
    }
  }

}
