import { Component, OnInit } from '@angular/core';
import { ExpenseService } from 'src/services/expense.service';
import { ActivatedRoute } from '@angular/router';

declare var google:any;

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.css']
})
export class AccountsComponent implements OnInit {

  id = this.activatedRoute.snapshot.paramMap.get("id")


  expenceAccountType:any = {}
  expenceDateType:any ={}

  constructor(private expenceService:ExpenseService, private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {
    this.getDetails();
    google.charts.load('current', {packages: ['corechart']});
    google.charts.setOnLoadCallback(()=>this.drawChart(this.expenceAccountType));  //calling the piechart function   
  }
//function for the pie chart
  drawChart(expenceAccountType:any){
    
    var data = new google.visualization.DataTable();
      data.addColumn('string', 'Topping');
      data.addColumn('number', 'Slices');

      let pieChartData = []
      for(const property in expenceAccountType){
        pieChartData.push([property,expenceAccountType[property]])
      }
      data.addRows(pieChartData);
      var options={
        title:'Pie Chart for Expense Account Type',
        pieHole: 0.4,
      };

      var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
      chart.draw(data, options);
    }

    getDetails(){
      this.expenceService.getExpenses(this.id).subscribe((response)=>{
        
        for(let i = 0;i<response.length;i++){
          console.log(response[i]);
          if(response[i].expenseAccountType.toUpperCase() in this.expenceAccountType){
            this.expenceAccountType[response[i].expenseAccountType.toUpperCase()]+=parseInt(response[i].expenseAmount)
          }else{
            this.expenceAccountType[response[i].expenseAccountType.toUpperCase()]=parseInt(response[i].expenseAmount)
          }
        }
        
  
      })
    }
  

}
