import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { LoginComponent } from 'src/auth/login/login.component';
import { SignupComponent } from 'src/auth/signup/signup.component';


@Component({
  selector: 'app-mainpage',
  templateUrl: './mainpage.component.html',
  styleUrls: ['./mainpage.component.css']
})
export class MainpageComponent implements OnInit {

  constructor(public dialog: MatDialog) {}

  openLogDialog() {
    this.dialog.open(LoginComponent);
  }

  openSignDialog() {
    this.dialog.open(SignupComponent);
  }

  ngOnInit(): void {
  }

}
