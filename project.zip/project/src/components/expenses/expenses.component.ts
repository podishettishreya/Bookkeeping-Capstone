import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ExpenseService } from 'src/services/expense.service';
import { CookieService } from 'ngx-cookie-service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-expenses',
  templateUrl: './expenses.component.html',
  styleUrls: ['./expenses.component.css']
})


export class ExpensesComponent implements OnInit {

  expence!:FormGroup;
  toppings = new FormControl('');
  toppingList: string[] = ['Paid', 'Unpaid'];

  pay = new FormControl('');
  payList: string[] = ['Credit', 'Debit'];
  id = this.activateRoute.snapshot.paramMap.get("id")
  constructor(private api:ExpenseService,private fb:FormBuilder,private cookieService:CookieService,private activateRoute:ActivatedRoute) { }

  ngOnInit(): void {
    this.expence = this.fb.group({
      name: ['', Validators.required],
      amount: ['',Validators.required],
      date:['',Validators.required],
      status:['',Validators.required],
      type:['',Validators.required],
      duedate:['',Validators.required],
      accounttype:['',Validators.required]
    })
  }

  submit(){
    if(this.expence.valid){
      console.log(this.expence.value)
      let data:any={}
      data['ExpenseName']= this.expence.value.name
      data['ExpenseAmount']= this.expence.value.amount
      data['ExpenseDate']= this.expence.value.date
      data['ExpenseStatus']= this.expence.value.status
      data['ExpenseType']= this.expence.value.type
      data['ExpenseDueDate']= this.expence.value.duedate
      data['ExpenseAccountType']= this.expence.value.accounttype
      data['UserId'] = this.id
      console.log(this.cookieService.getAll())
      console.log(data)
      this.api.postExpense(data).subscribe({
        next:(response)=>{alert("expense added")},
        error:(err)=>console.log(err)
      })
    }
  }


}
