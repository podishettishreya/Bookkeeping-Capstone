import { ActivatedRoute } from '@angular/router';
import { ExpenseService } from 'src/services/expense.service';
import { Component, OnInit } from '@angular/core';



declare var google:any;

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})



export class ReportsComponent implements OnInit {


  
  id = this.activatedRoute.snapshot.paramMap.get("id")

  expenceType:any = {}
  expenceDateType:any ={}

  creditTotal:number=0
  debitTotal:number=0

  constructor(private expenceService:ExpenseService, private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {
    this.getDetails();
    google.charts.load('current', {packages: ['corechart']});
    google.charts.setOnLoadCallback(()=>this.drawChart(this.expenceType));  //calling the piechart function   
    google.charts.setOnLoadCallback(()=>this.drawBarChart(this.expenceDateType)); //calling the barchart function
  }
//function for the pie chart
  drawChart(expenceType:any){
    
    var data = new google.visualization.DataTable();
      data.addColumn('string', 'Topping');
      data.addColumn('number', 'Slices');
      // data.addRows([
      //   ['Mushrooms', 3],
      //   ['Onions', 1],
      //   ['Olives', 1], 
      //   ['Zucchini', 1],
      //   ['Pepperoni', 2]
      // ]);

      let pieChartData = []
      for(const property in expenceType){
        pieChartData.push([property,expenceType[property]])
      }
      data.addRows(pieChartData);
      var options={
        title:'Pie Chart for Expense Type',
      };

      var chart = new google.visualization.PieChart(document.getElementById('divPieChart'));
      chart.draw(data, options);
    }
//function for the bar chart
    drawBarChart(expence:any) {
      console.log(expence);
      let arr = [];
      for(const property in expence){
        let color:string = "#"+Math.trunc(Math.random() * 100)+Math.trunc(Math.random() * 100)+Math.trunc(Math.random() * 100)
        arr.push([property,expence[property],color])
      }
      console.log(arr)
      var data = google.visualization.arrayToDataTable([
        ["Date", "Amount", { role: "style" } ],
        ...arr
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "Date vs Amount Spent",
        width: 1000,
        height: 400,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.BarChart(document.getElementById("barchart_values"));
      chart.draw(view, options);
  }

  getDetails(){
    this.expenceService.getExpenses(this.id).subscribe((response)=>{
      console.log(response)
      
      for(let i = 0;i<response.length;i++){
        console.log(response[i]);
        if(response[i].expenseName.toUpperCase() in this.expenceType){
          this.expenceType[response[i].expenseName.toUpperCase()]+=parseInt(response[i].expenseAmount)
        }else{
          this.expenceType[response[i].expenseName.toUpperCase()]=parseInt(response[i].expenseAmount)
        }
      }
      
      // expenceDateType
      console.log(response[0].expenseDate.split("T"))
      for(let i = 0;i<response.length;i++){
        console.log(response[i]);
        if(response[i].expenseName in this.expenceDateType){
          this.expenceDateType[response[i].expenseDate.split("T")[0]]+=parseInt(response[i].expenseAmount)
        }else{
          this.expenceDateType[response[i].expenseDate.split("T")[0]]=parseInt(response[i].expenseAmount)
        }
      }


      for(let i = 0;i<response.length;i++){
        if(response[i]["expenseType"]==="Debit"){
          this.debitTotal+=parseInt(response[i]["expenseAmount"])
        }else{
          this.creditTotal+=parseInt(response[i]["expenseAmount"])
        }
        
      }

      console.log(this.expenceDateType)

    })
  }


  }

  

