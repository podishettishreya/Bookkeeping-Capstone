import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ExpenseService } from 'src/services/expense.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  id=this.activatedRoute.snapshot.paramMap.get("id")
  constructor(private activatedRoute:ActivatedRoute,private api:ExpenseService,private router:Router) { }


  deadLines:any=[]

  ngOnInit(): void {
    this.api.getExpenses(this.id).subscribe((response:[])=>{
      // console.log(response)
      response.forEach((el:any)=>{
        // console.log(el)
        if(el["expenseStatus"]==="Unpaid"){
          let obj = {...el}
          obj["expenseDueDate"] = el["expenseDueDate"].split("T")[0]
          obj["expenseDate"] = el["expenseDate"].split("T")[0]

          this.deadLines.push(obj)
        }})
    })
    // console.log(this.deadLines)
    
  }

  public delete(id:string){
    this.api.deleteExpense(id).subscribe((response)=>{console.log(response)});
    this.router.navigate([`/homepage/${this.id}`])
  }

}
