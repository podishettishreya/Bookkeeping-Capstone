import { FormGroup,FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from 'src/services/user-service.service';
import {CookieService} from 'ngx-cookie-service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login!:FormGroup;

  constructor(private fb:FormBuilder,
    private api:UserServiceService,
    private router:Router,private cookieService:CookieService) { }

  ngOnInit(): void {
    this.login=this.fb.group({
      name:["",Validators.required],
      password:["",Validators.required]
    });
  }
 
submit(){
  console.log("Hello")
  this.api.Login(this.login.value).subscribe((response)=>{
    if(response){
      this.login.reset();
      this.router.navigate([`/homepage/${response.id}`])
    }else{
      alert('Username or password is wrong')
    }
  }
  //   {
  //   next:(response)=>{
  //     console.log(response)
      
  //     this.login.reset(); 
  //     this.router.navigate(['/homepage'])
  //   },
  //   error:(err)=>{
  //     alert('User DoesNot Exist.')
  //   }
  // }
  )
 }

}


// (res,err)=>{
//   console.log(res); 
// //  let user=res.find((x:any)=>x.password===this.login.value.password)

// //  if(user){
// //  alert('login is successful')
// //  this.login.reset(); 
// //  this.router.navigate(['/homepage'])

// // }
// // else{
// //  alert('user not found')
// // }

// }