import { UserServiceService } from './../../services/user-service.service';
import { MatDialog } from '@angular/material/dialog';
import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginComponent } from '../login/login.component';
import { User } from 'src/utilities/user';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  // constructor(private userServiceService:UserServiceService,private router:Router){
    
  // }
  // username:string="";
  // email:string="";
  // password:string="";

  // ngOnInit(): void {
    
  // }

  signup!:FormGroup;
  constructor( private fb:FormBuilder,
    private api:UserServiceService,
    private router:Router,
    private dialog:MatDialog)
     { }
     ngOnInit(): void {

      this.signup = this.fb.group({
  
        name: ['', Validators.required],
  
        password: ['', Validators.required],
  
      });
  
    }
  
  
  
    submit(){
  
      if(this.signup.valid){
  
        this.api.postDetails(this.signup.value)
  
        .subscribe({
  
          next:(response)=>{
  
            alert('signup is successful')
  
            this.signup.reset();
  
            // this.router.navigate(['/login']);
  
            this.dialog.open(LoginComponent,{
  
              width: '30%',
  
            });
  
          },
  
          error:()=>{
  
            alert('signup is not successful')
  
          }
  
        })
  
      }
  

}

}