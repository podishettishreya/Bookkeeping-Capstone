import { ReportsComponent } from './../components/reports/reports.component';
import { AccountsComponent } from './../components/accounts/accounts.component';
import { JournalComponent } from './../components/journal/journal.component';
import { LoginComponent } from './../auth/login/login.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from 'src/components/homepage/homepage.component';
import { MainComponent } from 'src/components/main/main.component';
import { ExpensesComponent } from 'src/components/expenses/expenses.component';
import { InvoiceComponent } from 'src/components/invoice/invoice.component';
import { ExpenseEditComponent } from 'src/components/expense-edit/expense-edit.component';



const routes: Routes = [
  {path:"login", component:LoginComponent},
  {path:"homepage/:id", component:HomepageComponent},
  {path:"expenses/:id",component:ExpensesComponent},
  {path:"invoice/:id",component:InvoiceComponent},
  {path:"journal/:id",component:JournalComponent},
  {path:"accounts/:id",component:AccountsComponent},
  {path:"reports/:id",component:ReportsComponent},
  {path:"expenses/:id/edit/:expenceId",component:ExpenseEditComponent},
  {path:"",component:MainComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
