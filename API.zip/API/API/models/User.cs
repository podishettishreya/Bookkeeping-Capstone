﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace API.models
{
    public class User
    {
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        [BsonId]

        public string id { get; set; } 
        public string Name { get; set; }
        public string Password { get; set; }
    }
}
