﻿using MongoDB.Bson.Serialization.Attributes;

namespace API.models
{
    public class ExpenseModel
    {
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        [BsonId]

        public string id { get; set; }
        public string ExpenseName { get; set; }
        public string ExpenseAmount { get; set; }

        public string ExpenseDate { get; set; }

        public string ExpenseStatus { get; set; }


        public string ExpenseType { get; set; }

        public string ExpenseDueDate { get; set; }

        public string ExpenseAccountType { get; set; }

        public string UserId { get; set; }
    }
}
