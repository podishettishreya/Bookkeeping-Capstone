﻿using API.models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace API.Controllers
{

    [ApiController]
    [Route("api/v1/expence")]
    public class ExpensesController:ControllerBase
    {
        private readonly IRepository.IExpenseService ExpenseService;

        public ExpensesController(IRepository.IExpenseService expenseService1)
        {
            this.ExpenseService = expenseService1;   
        }

        [HttpPost]
        public IActionResult InsertExpense(ExpenseModel model)
        {
           

            ExpenseModel expence =  ExpenseService.Add(model);
             
            return Ok();
        }

        [HttpGet]
        public IActionResult GetAll(string id)
        {
            Console.WriteLine(id);
            List<ExpenseModel> expences = ExpenseService.GetAll(id);
            return Ok(expences);
        }

        [HttpPatch]
        public IActionResult PatchExpense(string id,string expenceId, ExpenseModel model)
        {
            Console.WriteLine("id = "+id+ "expenceId = " + expenceId);
            ExpenseModel updateDoc = ExpenseService.Update(id, expenceId, model);
            return Ok(updateDoc);
        }
        [HttpDelete]
        public IActionResult DeleteExpense(string expenceId)
        {
            Console.WriteLine("Delete Expense" + expenceId);
            ExpenseService.Delete(expenceId);
            return Ok();
        }
    }
}
