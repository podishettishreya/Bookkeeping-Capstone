﻿using API.models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;

namespace API.Controllers
{
    public class SignUp
    {
        public int ID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }



    [ApiController]
    [Route("api/v1/student")]
    public class BookkController : ControllerBase
    {
        private readonly IRepository.IUserService userService1;

        public BookkController(IRepository.IUserService userService)
        {
            userService1 = userService;
        }


        [HttpGet]
        public IActionResult login(string name, string password)
        {
            Console.WriteLine(name + " " + password);


            //userService1.GetHashCode()
            try
            {
                User user = userService1.Get(name);

                if (user.Password == password)
                {
                    //Response.Cookies("userId").value = user.id;
                    //Response.Cookies("userName").Expires = DateTime.Now.AddDays(1);
                    CookieOptions options = new CookieOptions();
                    options.Expires = DateTime.Now.AddDays(2);
                    options.Secure = true;

                    Response.Cookies.Append("user_id",user.id, options);
                    
                    return Ok(user);
                }

                return BadRequest();
            }
            catch(Exception e)
            {
                return BadRequest(e);
            }
        }

        [HttpPost]
        public IActionResult AddUser(User user)
        {
            Console.WriteLine(user);
            userService1.AddUser(user);
            return Ok(user);
        }










        /*[HttpGet]
        public List<SignUp> GetAllSignup()
        {
            try
            {
                SqlConnection connection = new SqlConnection("Data Source=APINP-ELPT54836\\MSSQLSERVER01;Database=project;User Id=sa;Password=guvi;Integrated Security=false;");

                connection.Open(); 
                string query = "select * from signup";

                SqlCommand cmd = new SqlCommand(query, connection); 
                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {
                    List<SignUp> students = new List<SignUp>(); SignUp signup = null; while (a.Read())
                    {
                        signup = new SignUp();
                        signup.ID = Convert.ToInt32(a["ID"]);
                        signup.UserName = a["Username"].ToString();
                        signup.Password = a["Password"].ToString();

                        students.Add(signup);
                    }
                    return students;
                }
            }
            catch (Exception)
            {

                throw;
            }
            return null;
        }

        [HttpPost]
        public void PostSignup(string name, string password)
        {
            SqlConnection connection = new SqlConnection("Data Source=APINP-ELPT54836\\MSSQLSERVER01;Database=project;User Id=sa;Password=guvi;Integrated Security=false;"); connection.Open();
            string query = "insert into signup (Username,Password) values(@Username,@Password)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.Add("@Username", SqlDbType.NVarChar).Value = name;
            command.Parameters.Add("@Password", SqlDbType.NVarChar).Value = password;
            command.ExecuteNonQuery();
        }*/






    }



}