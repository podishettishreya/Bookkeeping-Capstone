﻿using API.repository;
using System.Collections.Generic;
using API.models;
using MongoDB.Bson;

namespace API.IRepository
{
    public interface IExpenseService
    {
        List<ExpenseModel> GetAll(string id);

        ExpenseModel Add(ExpenseModel model);

        ExpenseModel Update(string id,string expenceId, ExpenseModel model);

        void Delete(string expenceId); 
    }
}
