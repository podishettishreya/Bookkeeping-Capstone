﻿using API.repository;
using System.Collections.Generic;
using API.models;
using MongoDB.Bson;

namespace API.IRepository
{
    public interface IUserService
    {
        List<User> GetAll();
        User Get(string name);
        User AddUser(User user);
    }
}
