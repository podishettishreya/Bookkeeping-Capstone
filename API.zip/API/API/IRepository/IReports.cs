﻿namespace API.IRepository
{
    public interface IReports
    {
    }
}
