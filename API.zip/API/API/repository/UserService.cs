﻿using System.Collections.Generic;
using API.models;
using MongoDB.Bson;
using MongoDB.Driver;

namespace API.repository
{
    public class UserService: IRepository.IUserService
    {

        private MongoClient _client;
        private IMongoDatabase _database;
        private IMongoCollection<User> _users;

        public UserService()
        {
            _client = new MongoClient("mongodb+srv://root:root@cluster0.tx3fjmv.mongodb.net/test");
            _database = _client.GetDatabase("major_project");
            _users = _database.GetCollection<User>("bookkeeping");
        }
        public List<User> GetAll()
        {
            //return new List<User>
            //{
            //    new User
            //    {
            //        Name="name", Password="password",
            //    }
            //};
            return _users.Find(user => true).ToList();
        }

        public User Get(string name)
        {
            return _users.Find((doc) => doc.Name==name).ToList()[0];
        }

        public User AddUser(User user)
        {
            _users.InsertOne(user);
            return user;
        }

    }
}
