﻿


using System;
using System.Collections.Generic;
using API.models;
using MongoDB.Bson;
using MongoDB.Driver;

namespace API.repository
{
    public class ExpenseService : IRepository.IExpenseService
    {

        private MongoClient _client;
        private IMongoDatabase _database;
        private IMongoCollection<ExpenseModel> _expences;

        public ExpenseService()
        {
            _client = new MongoClient("mongodb+srv://root:root@cluster0.tx3fjmv.mongodb.net/");
            _database = _client.GetDatabase("major_project");
            _expences = _database.GetCollection<ExpenseModel>("expences");
        }
        public List<ExpenseModel> GetAll(string id)
        {
            //return new List<User>
            //{
            //    new User
            //    {
            //        Name="name", Password="password",
            //    }
            //};
            return _expences.Find((doc) => doc.UserId==id).ToList();
        }

        public ExpenseModel Add(ExpenseModel doc)
        {
            Console.WriteLine(doc.ExpenseName);
            _expences.InsertOne(doc);
            return doc;
        }

        public ExpenseModel Update(string id, string expenceId, ExpenseModel model)
        {
            Console.WriteLine("id = " + id + "expenceId = " + expenceId);
            _expences.FindOneAndDelete<ExpenseModel>(Builders<ExpenseModel>.Filter.Eq("id", expenceId));
            _expences.InsertOne(model);
            return model;
        }

        public void Delete(string expenceId)
        {
             _expences.DeleteOne(Builders<ExpenseModel>.Filter.Eq("id", expenceId));
        }
      

    }
}
